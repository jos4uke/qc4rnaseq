library(testthat)
library(dendextend)
test_package("dendextend")

library(dendextendRcpp)
test_package("dendextend")

# test_dir("inst\\tests")
# options()
# system.time(test_dir("inst\\tests")) # 78
# library(dendextendRcpp)
# system.time(test_dir("inst\\tests")) # 13.4
# search()
